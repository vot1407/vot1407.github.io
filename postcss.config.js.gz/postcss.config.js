// postcss.config.js
export const plugins = {
    tailwindcss: {},
    autoprefixer: {},
};
